# RUDNIK Game Lab: configurar o Pix do VIP

O VIP é pago por Pix através do Mercado Pago. As funções na pasta `api/` geram o Pix,
confirmam o pagamento e liberam o VIP sozinhas.

## 1. Mercado Pago
1. Tenha uma conta no Mercado Pago com uma **chave Pix cadastrada** nela.
2. Acesse **Suas integrações** (mercadopago.com.br/developers) e crie uma aplicação
   escolhendo **Checkout Transparente** (o Pix é gerado dentro do próprio site).
3. Em **Credenciais de produção**, copie o **Access Token** (começa com `APP_USR-`).
   Ele é secreto: não coloque no código nem no GitHub.

## 2. GitHub
Suba a pasta inteira (com `api/`, `package.json` e tudo mais). O `.gitignore` já impede
que um arquivo `.env` com segredos vá junto.

## 3. Vercel
1. Importe o repositório do GitHub (Add New → Project).
2. Em **Settings → Environment Variables**, crie:
   - `MP_ACCESS_TOKEN` = o Access Token do passo 1
   - `VIP_SECRET` = uma frase longa e aleatória só sua
   - `VIP_PRICE` = `9.90` (VIP total, todos os jogos)
   - `VIP_GAME_PRICE` = `4.90` (VIP de um jogo só)
3. Faça um novo deploy (Deployments → Redeploy) para as variáveis valerem.

## 4. Teste real
Compre o VIP com seu próprio Pix (R$ 9,90). O VIP deve ativar sozinho em poucos segundos.
Depois, se quiser, devolva o valor pelo painel do Mercado Pago.

## O que está à venda
- **VIP total (R$ 9,90):** libera todos os jogos, inclusive os próximos. Vendido no hub e dentro dos jogos.
- **VIP de um jogo (R$ 4,90):** vendido dentro de cada jogo, que mostra as duas opções lado a lado.
- Quem tem o VIP total nunca é cobrado pelo VIP de um jogo: o jogo já abre como VIP.
- Quem comprou um jogo e depois compra o VIP total passa a ter todos liberados.
- **Itens das lojas** (cobrados por Pix a cada compra; os preços ficam em `PRODUCTS`, api/_lib.js):
  Atacarejo: pacote de caixa R$ 2,90 · Ponte Zumbi: acelerador R$ 1,90, tiro 2x / reforço / escudo
  R$ 0,99, Pacote Sobrevivente R$ 3,90 · Muralha de Ouro: 200 moedas R$ 1,90, 600 moedas R$ 4,90.
- Se a pessoa fechar o jogo antes de o Pix cair, o item é entregue na próxima vez que ela abrir o jogo,
  uma vez só.

## Jogo novo com VIP
1. Adicione o jogo em `PRODUCTS` (api/_lib.js) e em `GAMES` (vip.js). Itens pagos: em `PRODUCTS`
   com `kind: 'item'` e em `ITEMS` (vip.js); no jogo, `RGL.register({ id: entregar })` e `RGL.pay(id)`.
2. No jogo, inclua `<script src="/vip.js"></script>` e chame `RGL.buy('slug-do-jogo', aoLiberar)`
   no botão de VIP; para saber se já é VIP, use `RGL.owns('slug-do-jogo')`.
3. Adicione o jogo na lista `GAMES` do index.html (hub).

## Como funciona
- `api/pix-create`: recebe o e-mail e o produto e gera o Pix (QR Code + copia e cola, expira em 30 min).
  Se o e-mail já tem o VIP total, ou já pagou aquele jogo, libera sem cobrar de novo.
- `api/pix-status`: o hub consulta a cada 4 segundos; quando o Pix cai, libera o VIP.
- `api/vip-restore`: "Já comprei em outro aparelho", devolve tudo o que o e-mail já pagou.
- Os preços são definidos no servidor; mudar o valor na página não muda a cobrança.
